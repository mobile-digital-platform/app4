import React from 'react';
import Root from './src/root';

import './polyfills';

export default (props) => <Root/>
