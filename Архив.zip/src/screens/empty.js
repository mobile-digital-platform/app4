import React from 'react';
import {StyleSheet,View} from 'react-native';

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: '#f40000',
	},
});

export default () => <View style={styles.container} />
