export default {
	name: 'mobile-digital-platform',
	version: '0.2.6',
	year: '2019',

	storage_name: 'coca-cola',

	base_width: 320,

	city: {
		limit: 30,
	},
};
