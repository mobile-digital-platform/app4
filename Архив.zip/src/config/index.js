export default {
	name: 'mobile-digital-platform',
	version: '0.2.0',
	year: '2019',
	support_number: '8-800-1112233',

	storage_name: 'coca-cola',

	city: {
		limit: 30,
	},
};
