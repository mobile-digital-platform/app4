export default {
	$white: '#fff',
	$red: '#f40000',
};
