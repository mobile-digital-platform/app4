// Исходное состояние хранилища

var init = () => ({
});
var initial = init();

export {initial,init};
